using System;
using System.Windows.Forms;

namespace ReservationApp
{
    class Program
    {
        [STAThread]
        static void Main()
        {
            Console.WriteLine("Программа запускается...");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form());
        }
    }
}