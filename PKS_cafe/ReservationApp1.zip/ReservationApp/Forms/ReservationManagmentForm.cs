using System;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;

public class ReservationManagementForm : Form
{
    private ReservationService reservationService = null!;
    private IContainer components = null!;
    private DataGridView dgvReservations = null!;
    private DataGridView dgvAvailableTables = null!;
    private Button btnCreateReservation = null!;
    private Button btnCancelReservation = null!;
    private Button btnShowAvailable = null!;
    private TextBox txtClientName = null!;
    private TextBox txtPhone = null!;
    private DateTimePicker dtpDate = null!;
    private DateTimePicker dtpStartTime = null!;
    private DateTimePicker dtpEndTime = null!;
    private TextBox txtComment = null!;
    private NumericUpDown numSeats = null!;
    private Label lblStatus = null!;

    public ReservationManagementForm(ReservationService service)
    {
        reservationService = service;
        InitializeUI();
        LoadReservations();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeUI()
    {
        components = new Container();
        dgvReservations = new DataGridView();
        dgvAvailableTables = new DataGridView();
        btnCreateReservation = new Button();
        btnCancelReservation = new Button();
        btnShowAvailable = new Button();
        txtClientName = new TextBox();
        txtPhone = new TextBox();
        dtpDate = new DateTimePicker();
        dtpStartTime = new DateTimePicker();
        dtpEndTime = new DateTimePicker();
        txtComment = new TextBox();
        numSeats = new NumericUpDown();
        lblStatus = new Label();

        this.Text = "Управление бронированиями";
        this.Size = new System.Drawing.Size(1200, 700);
        this.StartPosition = FormStartPosition.CenterScreen;

        // Панель управления
        var panelControls = new Panel
        {
            Dock = DockStyle.Top,
            Height = 200,
            BorderStyle = BorderStyle.FixedSingle
        };

        // Поля для создания брони
        var lblClientName = new Label { Text = "Имя клиента:", Location = new System.Drawing.Point(20, 20), Width = 100 };
        txtClientName = new TextBox { Location = new System.Drawing.Point(120, 20), Width = 200 };

        var lblPhone = new Label { Text = "Телефон:", Location = new System.Drawing.Point(20, 50), Width = 100 };
        txtPhone = new TextBox { Location = new System.Drawing.Point(120, 50), Width = 200 };

        var lblDate = new Label { Text = "Дата:", Location = new System.Drawing.Point(20, 80), Width = 100 };
        dtpDate = new DateTimePicker { Location = new System.Drawing.Point(120, 80), Width = 200, Format = DateTimePickerFormat.Short };

        var lblStartTime = new Label { Text = "Время начала:", Location = new System.Drawing.Point(20, 110), Width = 100 };
        dtpStartTime = new DateTimePicker { Location = new System.Drawing.Point(120, 110), Width = 200, Format = DateTimePickerFormat.Time, ShowUpDown = true };

        var lblEndTime = new Label { Text = "Время окончания:", Location = new System.Drawing.Point(20, 140), Width = 100 };
        dtpEndTime = new DateTimePicker { Location = new System.Drawing.Point(120, 140), Width = 200, Format = DateTimePickerFormat.Time, ShowUpDown = true };

        var lblSeats = new Label { Text = "Количество мест:", Location = new System.Drawing.Point(350, 20), Width = 120 };
        numSeats = new NumericUpDown { Location = new System.Drawing.Point(480, 20), Width = 100, Minimum = 1, Maximum = 20, Value = 2 };

        var lblComment = new Label { Text = "Комментарий:", Location = new System.Drawing.Point(350, 50), Width = 120 };
        txtComment = new TextBox { Location = new System.Drawing.Point(480, 50), Width = 200, Height = 60, Multiline = true };

        btnShowAvailable = new Button { Text = "Показать доступные столы", Location = new System.Drawing.Point(350, 120), Width = 150 };
        btnShowAvailable.Click += (s, e) => ShowAvailableTables();

        btnCreateReservation = new Button { Text = "Создать бронь", Location = new System.Drawing.Point(510, 120), Width = 100 };
        btnCreateReservation.Click += (s, e) => CreateReservation();

        lblStatus = new Label { Text = "", Location = new System.Drawing.Point(350, 160), Width = 400, ForeColor = System.Drawing.Color.Blue };

        panelControls.Controls.AddRange(new Control[] {
            lblClientName, txtClientName, lblPhone, txtPhone,
            lblDate, dtpDate, lblStartTime, dtpStartTime, lblEndTime, dtpEndTime,
            lblSeats, numSeats, lblComment, txtComment,
            btnShowAvailable, btnCreateReservation, lblStatus
        });

        // Таблица доступных столов
        var lblAvailableTables = new Label { Text = "Доступные столы:", Location = new System.Drawing.Point(20, 180), Width = 200 };
        dgvAvailableTables = new DataGridView
        {
            Location = new System.Drawing.Point(20, 210),
            Size = new System.Drawing.Size(400, 200),
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect
        };

        // Таблица всех бронирований
        var lblAllReservations = new Label { Text = "Все бронирования:", Location = new System.Drawing.Point(450, 180), Width = 200 };
        dgvReservations = new DataGridView
        {
            Location = new System.Drawing.Point(450, 210),
            Size = new System.Drawing.Size(700, 200),
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect
        };

        btnCancelReservation = new Button { Text = "Отменить бронь", Location = new System.Drawing.Point(450, 420), Width = 120 };
        btnCancelReservation.Click += (s, e) => CancelReservation();

        this.Controls.AddRange(new Control[] {
            panelControls, lblAvailableTables, dgvAvailableTables,
            lblAllReservations, dgvReservations, btnCancelReservation
        });

        ConfigureDataGridViews();
    }

    private void ConfigureDataGridViews()
    {
        // Настройка таблицы доступных столов
        dgvAvailableTables.Columns.Clear();
        dgvAvailableTables.Columns.Add("Id", "ID");
        dgvAvailableTables.Columns.Add("Location", "Расположение");
        dgvAvailableTables.Columns.Add("Seats", "Мест");
        dgvAvailableTables.Columns.Add("Status", "Статус");

        // Настройка таблицы бронирований
        dgvReservations.Columns.Clear();
        dgvReservations.Columns.Add("Id", "ID");
        dgvReservations.Columns.Add("ClientName", "Клиент");
        dgvReservations.Columns.Add("Phone", "Телефон");
        dgvReservations.Columns.Add("StartTime", "Начало");
        dgvReservations.Columns.Add("EndTime", "Окончание");
        dgvReservations.Columns.Add("Table", "Стол");
        dgvReservations.Columns.Add("Status", "Статус");
    }

    private void LoadReservations()
    {
        var reservations = reservationService.GetAllReservations();
        dgvReservations.Rows.Clear();

        foreach (var res in reservations)
        {
            var status = res.IsActive() ? "Активна" : 
                        res.StartTime > DateTime.Now ? "Ожидание" : "Завершена";
            
            dgvReservations.Rows.Add(
                res.Id,
                res.ClientName,
                res.Phone,
                res.StartTime.ToString("dd.MM.yyyy HH:mm"),
                res.EndTime.ToString("dd.MM.yyyy HH:mm"),
                res.AssignedTable?.Id,
                status
            );
        }
    }

    private void ShowAvailableTables()
    {
        if (string.IsNullOrEmpty(txtClientName.Text) || string.IsNullOrEmpty(txtPhone.Text))
        {
            lblStatus.Text = "Заполните имя и телефон клиента";
            return;
        }

        try
        {
            var startDateTime = dtpDate.Value.Date + dtpStartTime.Value.TimeOfDay;
            var endDateTime = dtpDate.Value.Date + dtpEndTime.Value.TimeOfDay;

            var availableTables = reservationService.GetAvailableTables(
                startDateTime, endDateTime, (int)numSeats.Value);

            dgvAvailableTables.Rows.Clear();
            foreach (var table in availableTables)
            {
                dgvAvailableTables.Rows.Add(
                    table.Id,
                    table.Location,
                    table.Seats,
                    table.IsActive ? "Доступен" : "Неактивен"
                );
            }

            lblStatus.Text = $"Найдено {availableTables.Count} доступных столов";
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Ошибка: {ex.Message}";
        }
    }

    private void CreateReservation()
    {
        if (dgvAvailableTables.SelectedRows.Count == 0)
        {
            lblStatus.Text = "Выберите стол из списка доступных";
            return;
        }

        try
        {
            // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
            if (dgvAvailableTables.SelectedRows[0].Cells["Id"].Value != null)
            {
                var tableId = (int)dgvAvailableTables.SelectedRows[0].Cells["Id"].Value;
                var table = reservationService.GetAllTables().First(t => t.Id == tableId);
                
                var startDateTime = dtpDate.Value.Date + dtpStartTime.Value.TimeOfDay;
                var endDateTime = dtpDate.Value.Date + dtpEndTime.Value.TimeOfDay;

                reservationService.CreateReservation(
                    txtClientName.Text.Trim(),
                    txtPhone.Text.Trim(),
                    startDateTime,
                    endDateTime,
                    txtComment.Text.Trim(),
                    table,
                    out var reservation
                );

                lblStatus.Text = $"Бронь #{reservation.Id} успешно создана!";
                ClearForm();
                LoadReservations();
            }
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Ошибка создания брони: {ex.Message}";
        }
    }

    private void CancelReservation()
    {
        if (dgvReservations.SelectedRows.Count == 0)
        {
            lblStatus.Text = "Выберите бронь для отмены";
            return;
        }

        // БЕЗОПАСНАЯ РАСПАКОВКА - добавлены проверки на null
        if (dgvReservations.SelectedRows[0].Cells["Id"].Value != null && 
            dgvReservations.SelectedRows[0].Cells["ClientName"].Value != null)
        {
            var reservationId = (int)dgvReservations.SelectedRows[0].Cells["Id"].Value;
            var clientName = dgvReservations.SelectedRows[0].Cells["ClientName"].Value.ToString() ?? "";

            var result = MessageBox.Show(
                $"Отменить бронь #{reservationId} для {clientName}?",
                "Подтверждение отмены",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                reservationService.CancelReservation(reservationId, out bool success);
                if (success)
                {
                    lblStatus.Text = $"Бронь #{reservationId} отменена";
                    LoadReservations();
                }
                else
                {
                    lblStatus.Text = "Не удалось отменить бронь";
                }
            }
        }
    }

    private void ClearForm()
    {
        txtClientName.Clear();
        txtPhone.Clear();
        txtComment.Clear();
        dgvAvailableTables.Rows.Clear();
    }
}