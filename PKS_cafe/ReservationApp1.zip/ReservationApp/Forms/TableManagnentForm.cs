using System;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;

public class TableManagementForm : Form
{
    private TableManagementService tableService = null!;
    private ReservationService reservationService = null!;
    private IContainer components = null!;
    private DataGridView dgvTables = null!;
    private Button btnAddTable = null!;
    private Button btnEditTable = null!;
    private Button btnToggleStatus = null!;
    private ComboBox cmbLocation = null!;
    private NumericUpDown numSeats = null!;
    private TextBox txtTableInfo = null!;
    private Label lblStatus = null!;

    public TableManagementForm(TableManagementService tableService, ReservationService reservationService)
    {
        this.tableService = tableService;
        this.reservationService = reservationService;
        InitializeUI();
        LoadTables();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeUI()
    {
        components = new Container();
        dgvTables = new DataGridView();
        btnAddTable = new Button();
        btnEditTable = new Button();
        btnToggleStatus = new Button();
        cmbLocation = new ComboBox();
        numSeats = new NumericUpDown();
        txtTableInfo = new TextBox();
        lblStatus = new Label();

        this.Text = "Управление столами";
        this.Size = new System.Drawing.Size(900, 600);
        this.StartPosition = FormStartPosition.CenterScreen;

        var splitContainer = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical };

        // Верхняя панель - управление
        var topPanel = new Panel { Dock = DockStyle.Fill, Height = 200 };
        InitializeTableForm(topPanel);

        // Нижняя панель - список столов и детальная информация
        var bottomPanel = new Panel { Dock = DockStyle.Fill };
        InitializeTablesGrid(bottomPanel);

        splitContainer.Panel1.Controls.Add(topPanel);
        splitContainer.Panel2.Controls.Add(bottomPanel);

        this.Controls.Add(splitContainer);
    }

    private void InitializeTableForm(Panel panel)
    {
        var lblTitle = new Label 
        { 
            Text = "Добавление/Редактирование стола", 
            Location = new System.Drawing.Point(10, 10),
            Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold),
            AutoSize = true
        };

        var lblLocation = new Label { Text = "Расположение:", Location = new System.Drawing.Point(10, 40) };
        cmbLocation = new ComboBox { Location = new System.Drawing.Point(100, 40), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
        cmbLocation.DataSource = Enum.GetValues(typeof(TableLocation));

        var lblSeats = new Label { Text = "Количество мест:", Location = new System.Drawing.Point(10, 70) };
        numSeats = new NumericUpDown { Location = new System.Drawing.Point(120, 70), Width = 80, Minimum = 1, Maximum = 20, Value = 4 };

        btnAddTable = new Button { Text = "Добавить стол", Location = new System.Drawing.Point(10, 110), Width = 100 };
        btnAddTable.Click += (s, e) => AddTable();

        btnEditTable = new Button { Text = "Сохранить изменения", Location = new System.Drawing.Point(120, 110), Width = 120 };
        btnEditTable.Click += (s, e) => EditTable();
        btnEditTable.Enabled = false;

        btnToggleStatus = new Button { Text = "Активировать/Деактивировать", Location = new System.Drawing.Point(250, 110), Width = 180 };
        btnToggleStatus.Click += (s, e) => ToggleTableStatus();

        lblStatus = new Label { Text = "", Location = new System.Drawing.Point(10, 150), Width = 500, ForeColor = System.Drawing.Color.Blue };

        panel.Controls.AddRange(new Control[] {
            lblTitle, lblLocation, cmbLocation, lblSeats, numSeats,
            btnAddTable, btnEditTable, btnToggleStatus, lblStatus
        });
    }

    private void InitializeTablesGrid(Panel panel)
    {
        var splitContainer = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal };

        // Верхняя панель - таблица столов
        var topPanel = new Panel { Dock = DockStyle.Fill };
        dgvTables = new DataGridView
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoGenerateColumns = false
        };

        dgvTables.Columns.Add("Id", "ID");
        dgvTables.Columns.Add("Location", "Расположение");
        dgvTables.Columns.Add("Seats", "Мест");
        dgvTables.Columns.Add("Status", "Статус");
        dgvTables.Columns.Add("ReservationsToday", "Бронирований сегодня");

        dgvTables.SelectionChanged += (s, e) => OnTableSelected();

        // Нижняя панель - детальная информация
        var bottomPanel = new Panel { Dock = DockStyle.Fill };
        var lblInfo = new Label 
        { 
            Text = "Детальная информация о столе:", 
            Location = new System.Drawing.Point(10, 10),
            Font = new System.Drawing.Font("Arial", 9, System.Drawing.FontStyle.Bold),
            AutoSize = true
        };

        txtTableInfo = new TextBox
        {
            Location = new System.Drawing.Point(10, 40),
            Size = new System.Drawing.Size(600, 150),
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Font = new System.Drawing.Font("Consolas", 9)
        };

        topPanel.Controls.Add(dgvTables);
        bottomPanel.Controls.Add(lblInfo);
        bottomPanel.Controls.Add(txtTableInfo);

        splitContainer.Panel1.Controls.Add(topPanel);
        splitContainer.Panel2.Controls.Add(bottomPanel);

        panel.Controls.Add(splitContainer);
    }

    private void LoadTables()
    {
        var tables = reservationService.GetAllTables();
        dgvTables.Rows.Clear();

        foreach (var table in tables.OrderBy(t => t.Id))
        {
            var reservationsToday = table.Reservations.Count(r => r.Key.Date == DateTime.Today);
            
            dgvTables.Rows.Add(
                table.Id,
                table.Location.ToString(),
                table.Seats,
                table.IsActive ? "Активен" : "Неактивен",
                reservationsToday
            );
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void OnTableSelected()
    {
        if (dgvTables.SelectedRows.Count > 0 && dgvTables.SelectedRows[0].Cells["Id"].Value != null)
        {
            var tableId = (int)dgvTables.SelectedRows[0].Cells["Id"].Value;
            var info = tableService.GetTableDetailedInfo(tableId);
            txtTableInfo.Text = info;

            btnEditTable.Enabled = true;
        }
        else
        {
            btnEditTable.Enabled = false;
            txtTableInfo.Clear();
        }
    }

    private void AddTable()
    {
        try
        {
            reservationService.CreateTable(
                (TableLocation)cmbLocation.SelectedItem,
                (int)numSeats.Value,
                out var table
            );

            lblStatus.Text = $"Стол #{table.Id} успешно добавлен!";
            LoadTables();
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Ошибка добавления стола: {ex.Message}";
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void EditTable()
    {
        if (dgvTables.SelectedRows.Count == 0)
        {
            lblStatus.Text = "Выберите стол для редактирования";
            return;
        }

        try
        {
            if (dgvTables.SelectedRows[0].Cells["Id"].Value != null)
            {
                var tableId = (int)dgvTables.SelectedRows[0].Cells["Id"].Value;
                
                tableService.EditTableInfo(
                    tableId,
                    (TableLocation)cmbLocation.SelectedItem,
                    (int)numSeats.Value,
                    out bool success
                );

                if (success)
                {
                    lblStatus.Text = $"Стол #{tableId} успешно обновлен!";
                    LoadTables();
                    OnTableSelected(); // Обновляем детальную информацию
                }
                else
                {
                    lblStatus.Text = "Не удалось обновить стол";
                }
            }
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Ошибка редактирования стола: {ex.Message}";
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void ToggleTableStatus()
    {
        if (dgvTables.SelectedRows.Count == 0)
        {
            lblStatus.Text = "Выберите стол";
            return;
        }

        if (dgvTables.SelectedRows[0].Cells["Id"].Value != null)
        {
            var tableId = (int)dgvTables.SelectedRows[0].Cells["Id"].Value;
            
            tableService.ToggleTableStatus(tableId, out bool newStatus);
            
            lblStatus.Text = $"Стол #{tableId} теперь {(newStatus ? "активен" : "неактивен")}";
            LoadTables();
            OnTableSelected();
        }
    }
}