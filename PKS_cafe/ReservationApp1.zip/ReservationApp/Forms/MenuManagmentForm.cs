using System;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;

public class MenuManagementForm : Form
{
    private OrderService orderService = null!;
    private IContainer components = null!;
    private DataGridView dgvDishes = null!;
    private Button btnAddDish = null!;
    private Button btnEditDish = null!;
    private Button btnToggleAvailability = null!;
    private TextBox txtDishName = null!;
    private TextBox txtIngredients = null!;
    private TextBox txtDescription = null!;
    private NumericUpDown numPrice = null!;
    private NumericUpDown numCookingTime = null!;
    private ComboBox cmbCategory = null!;
    private Label lblStatus = null!;

    public MenuManagementForm(OrderService service)
    {
        orderService = service;
        InitializeUI();
        LoadDishes();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeUI()
    {
        components = new Container();
        dgvDishes = new DataGridView();
        btnAddDish = new Button();
        btnEditDish = new Button();
        btnToggleAvailability = new Button();
        txtDishName = new TextBox();
        txtIngredients = new TextBox();
        txtDescription = new TextBox();
        numPrice = new NumericUpDown();
        numCookingTime = new NumericUpDown();
        cmbCategory = new ComboBox();
        lblStatus = new Label();

        this.Text = "Управление меню";
        this.Size = new System.Drawing.Size(1000, 600);
        this.StartPosition = FormStartPosition.CenterScreen;

        var splitContainer = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical };

        // Верхняя панель - форма добавления/редактирования
        var topPanel = new Panel { Dock = DockStyle.Fill, Height = 250 };
        InitializeDishForm(topPanel);

        // Нижняя панель - список блюд
        var bottomPanel = new Panel { Dock = DockStyle.Fill };
        InitializeDishesGrid(bottomPanel);

        splitContainer.Panel1.Controls.Add(topPanel);
        splitContainer.Panel2.Controls.Add(bottomPanel);

        this.Controls.Add(splitContainer);
    }

    private void InitializeDishForm(Panel panel)
    {
        var lblTitle = new Label 
        { 
            Text = "Добавление/Редактирование блюда", 
            Location = new System.Drawing.Point(10, 10),
            Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold),
            AutoSize = true
        };

        var lblName = new Label { Text = "Название:", Location = new System.Drawing.Point(10, 40) };
        txtDishName = new TextBox { Location = new System.Drawing.Point(100, 40), Width = 200 };

        var lblCategory = new Label { Text = "Категория:", Location = new System.Drawing.Point(10, 70) };
        cmbCategory = new ComboBox { Location = new System.Drawing.Point(100, 70), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
        cmbCategory.DataSource = Enum.GetValues(typeof(DishCategory));

        var lblPrice = new Label { Text = "Цена (руб.):", Location = new System.Drawing.Point(10, 100) };
        numPrice = new NumericUpDown { Location = new System.Drawing.Point(100, 100), Width = 100, Minimum = 0, Maximum = 10000, DecimalPlaces = 2 };

        var lblCookingTime = new Label { Text = "Время готовки (мин.):", Location = new System.Drawing.Point(10, 130) };
        numCookingTime = new NumericUpDown { Location = new System.Drawing.Point(150, 130), Width = 80, Minimum = 0, Maximum = 180 };

        var lblIngredients = new Label { Text = "Состав:", Location = new System.Drawing.Point(10, 160) };
        txtIngredients = new TextBox { Location = new System.Drawing.Point(100, 160), Width = 300, Height = 40, Multiline = true };

        var lblDescription = new Label { Text = "Описание:", Location = new System.Drawing.Point(10, 210) };
        txtDescription = new TextBox { Location = new System.Drawing.Point(100, 210), Width = 300, Height = 40, Multiline = true };

        btnAddDish = new Button { Text = "Добавить блюдо", Location = new System.Drawing.Point(420, 40), Width = 120 };
        btnAddDish.Click += (s, e) => AddDish();

        btnEditDish = new Button { Text = "Сохранить изменения", Location = new System.Drawing.Point(420, 80), Width = 120 };
        btnEditDish.Click += (s, e) => EditDish();
        btnEditDish.Enabled = false;

        btnToggleAvailability = new Button { Text = "Вкл/Выкл доступность", Location = new System.Drawing.Point(420, 120), Width = 120 };
        btnToggleAvailability.Click += (s, e) => ToggleDishAvailability();

        lblStatus = new Label { Text = "", Location = new System.Drawing.Point(420, 160), Width = 300, ForeColor = System.Drawing.Color.Blue };

        panel.Controls.AddRange(new Control[] {
            lblTitle, lblName, txtDishName, lblCategory, cmbCategory,
            lblPrice, numPrice, lblCookingTime, numCookingTime,
            lblIngredients, txtIngredients, lblDescription, txtDescription,
            btnAddDish, btnEditDish, btnToggleAvailability, lblStatus
        });
    }

    private void InitializeDishesGrid(Panel panel)
    {
        dgvDishes = new DataGridView
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoGenerateColumns = false
        };

        dgvDishes.Columns.Add("Id", "ID");
        dgvDishes.Columns.Add("Name", "Название");
        dgvDishes.Columns.Add("Category", "Категория");
        dgvDishes.Columns.Add("Price", "Цена");
        dgvDishes.Columns.Add("CookingTime", "Время готовки");
        dgvDishes.Columns.Add("Available", "Доступно");
        dgvDishes.Columns.Add("Ingredients", "Состав");

        dgvDishes.SelectionChanged += (s, e) => OnDishSelected();

        panel.Controls.Add(dgvDishes);
    }

    private void LoadDishes()
    {
        var dishes = orderService.GetAllDishes();
        dgvDishes.Rows.Clear();

        foreach (var dish in dishes.OrderBy(d => d.Category).ThenBy(d => d.Name))
        {
            dgvDishes.Rows.Add(
                dish.Id,
                dish.Name,
                dish.Category.ToString(),
                $"{dish.Price} руб.",
                $"{dish.CookingTime} мин.",
                dish.IsAvailable ? "✅" : "❌",
                dish.Ingredients.Length > 50 ? dish.Ingredients.Substring(0, 47) + "..." : dish.Ingredients
            );
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void OnDishSelected()
    {
        if (dgvDishes.SelectedRows.Count > 0 && dgvDishes.SelectedRows[0].Cells["Id"].Value != null)
        {
            var dishId = (int)dgvDishes.SelectedRows[0].Cells["Id"].Value;
            var dish = orderService.GetAllDishes().First(d => d.Id == dishId);
            
            txtDishName.Text = dish.Name;
            cmbCategory.SelectedItem = dish.Category;
            numPrice.Value = dish.Price;
            numCookingTime.Value = dish.CookingTime;
            txtIngredients.Text = dish.Ingredients;
            txtDescription.Text = dish.Description;

            btnAddDish.Enabled = false;
            btnEditDish.Enabled = true;
        }
        else
        {
            btnAddDish.Enabled = true;
            btnEditDish.Enabled = false;
        }
    }

    private void AddDish()
    {
        if (string.IsNullOrEmpty(txtDishName.Text) || string.IsNullOrEmpty(txtIngredients.Text))
        {
            lblStatus.Text = "Заполните название и состав блюда";
            return;
        }

        try
        {
            orderService.CreateDish(
                txtDishName.Text.Trim(),
                txtIngredients.Text.Trim(),
                numPrice.Value,
                (DishCategory)cmbCategory.SelectedItem,
                (int)numCookingTime.Value,
                txtDescription.Text.Trim(),
                out var dish
            );

            lblStatus.Text = $"Блюдо \"{dish.Name}\" успешно добавлено!";
            ClearForm();
            LoadDishes();
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Ошибка добавления блюда: {ex.Message}";
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void EditDish()
    {
        if (dgvDishes.SelectedRows.Count == 0)
        {
            lblStatus.Text = "Выберите блюдо для редактирования";
            return;
        }

        try
        {
            if (dgvDishes.SelectedRows[0].Cells["Id"].Value != null)
            {
                var dishId = (int)dgvDishes.SelectedRows[0].Cells["Id"].Value;
                var dish = orderService.GetAllDishes().First(d => d.Id == dishId);
                
                // В реальном приложении здесь был бы вызов метода редактирования
                dish.Name = txtDishName.Text.Trim();
                dish.Ingredients = txtIngredients.Text.Trim();
                dish.Price = numPrice.Value;
                dish.CookingTime = (int)numCookingTime.Value;
                dish.Description = txtDescription.Text.Trim();
                dish.Category = (DishCategory)cmbCategory.SelectedItem;

                lblStatus.Text = $"Блюдо \"{dish.Name}\" успешно обновлено!";
                LoadDishes();
            }
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Ошибка редактирования блюда: {ex.Message}";
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлены проверки на null
    private void ToggleDishAvailability()
    {
        if (dgvDishes.SelectedRows.Count == 0)
        {
            lblStatus.Text = "Выберите блюдо";
            return;
        }

        if (dgvDishes.SelectedRows[0].Cells["Id"].Value != null && 
            dgvDishes.SelectedRows[0].Cells["Name"].Value != null)
        {
            var dishId = (int)dgvDishes.SelectedRows[0].Cells["Id"].Value;
            var dishName = dgvDishes.SelectedRows[0].Cells["Name"].Value.ToString() ?? "";
            
            orderService.ToggleDishAvailability(dishId, out bool newStatus);
            
            lblStatus.Text = $"Блюдо \"{dishName}\" теперь {(newStatus ? "доступно" : "недоступно")}";
            LoadDishes();
        }
    }

    private void ClearForm()
    {
        txtDishName.Clear();
        txtIngredients.Clear();
        txtDescription.Clear();
        numPrice.Value = 0;
        numCookingTime.Value = 0;
        cmbCategory.SelectedIndex = 0;
        dgvDishes.ClearSelection();
        
        btnAddDish.Enabled = true;
        btnEditDish.Enabled = false;
    }
}