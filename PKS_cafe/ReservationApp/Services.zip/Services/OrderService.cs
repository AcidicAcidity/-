using System;
using System.Collections.Generic;
using ReservationApp.Models; // если вы используете свои модели
using System.Linq;

public class OrderService
{
    private List<Dish> dishes = new();
    private List<Order> orders = new();
    private List<Waiter> waiters = new();
    private int nextDishId = 1;
    private int nextOrderId = 1;
    private int nextWaiterId = 1;
    private ReservationService reservationService;

    public OrderService(ReservationService resService)
    {
        reservationService = resService;
        SeedSampleData();
    }

    private void SeedSampleData()
    {
        // Создаем официантов
        waiters.Add(new Waiter().CreateWaiter(nextWaiterId++, "Анна Сергеева", "79161112233"));
        waiters.Add(new Waiter().CreateWaiter(nextWaiterId++, "Дмитрий Петров", "79162223344"));
        waiters.Add(new Waiter().CreateWaiter(nextWaiterId++, "Мария Иванова", "79163334455"));

        // Создаем меню
        dishes.Add(new Dish().CreateDish(nextDishId++, "Цезарь с курицей",
            "Курица, салат айсберг, пармезан, сухарики, соус цезарь", 450, DishCategory.Salads, 10, "Классический салат Цезарь"));
        dishes.Add(new Dish().CreateDish(nextDishId++, "Борщ украинский",
            "Говядина, свекла, капуста, картофель, сметана", 350, DishCategory.Soups, 15, "Наваристый борщ по-украински"));
        dishes.Add(new Dish().CreateDish(nextDishId++, "Стейк Рибай",
            "Говядина, розмарин, чеснок, оливковое масло", 1200, DishCategory.MainCourses, 25, "Стейк премиум класса"));
        dishes.Add(new Dish().CreateDish(nextDishId++, "Кофе Латте",
            "Эспрессо, молоко, пенка", 250, DishCategory.Drinks, 5, "Нежный кофе с молочной пенкой"));
        dishes.Add(new Dish().CreateDish(nextDishId++, "Тирамису",
            "Маскарпоне, кофе, бисквит, какао", 380, DishCategory.Desserts, 0, "Итальянский десерт"));
        dishes.Add(new Dish().CreateDish(nextDishId++, "Брускетта с томатами",
            "Хлеб, помидоры, базилик, чеснок", 280, DishCategory.ColdAppetizers, 8, "Итальянская закуска"));
        dishes.Add(new Dish().CreateDish(nextDishId++, "Креветки в чесночном соусе",
            "Креветки, чеснок, сливки, белое вино", 650, DishCategory.HotAppetizers, 12, "Нежные креветки в сливочном соусе"));

        // Создаем тестовые заказы
        var table1 = reservationService.GetAllTables()[0];
        var waiter1 = waiters[0];
        var selectedDishes = new[] { dishes[0], dishes[1], dishes[4] };

        CreateOrder(table1.Id, waiter1.Id, waiter1.Name, "Соль и переч на столе", selectedDishes);
    }

    public void CreateDish(in string name, in string ingredients, in decimal price,
        in DishCategory category, in int cookingTime, in string description, out Dish dish)
    {
        dish = new Dish().CreateDish(nextDishId++, name, ingredients, price, category, cookingTime, description);
        dishes.Add(dish);
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public void CreateOrder(int tableId, int waiterId, string waiterName, string comment, params Dish[] selectedDishes)
    {
        // Проверка на бронь стола
        var activeReservations = reservationService.GetActiveReservations();
        var isTableReserved = activeReservations.Any(r =>
            r.AssignedTable != null && r.AssignedTable.Id == tableId);

        if (isTableReserved)
        {
            throw new InvalidOperationException($"Стол #{tableId} забронирован! Нельзя создать заказ.");
        }

        if (!selectedDishes.Any())
        {
            throw new InvalidOperationException("Добавьте хотя бы одно блюдо в заказ!");
        }

        var unavailableDishes = selectedDishes.Where(d => !d.IsAvailable).ToList();
        if (unavailableDishes.Any())
        {
            throw new InvalidOperationException($"Следующие блюда недоступны: {string.Join(", ", unavailableDishes.Select(d => d.Name))}");
        }

        var order = new Order().CreateOrder(nextOrderId++, tableId, waiterId, waiterName, comment, selectedDishes);
        orders.Add(order);
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public List<Dish> GetDishesByCategory(DishCategory category)
    {
        return dishes.Where(d => d.Category == category && d.IsAvailable).ToList();
    }

    public List<Dish> GetAllDishes()
    {
        return dishes;
    }

    public List<Order> GetActiveOrders()
    {
        return orders.Where(o => o.Status != OrderStatus.Closed).ToList();
    }

    public List<Order> GetAllOrders()
    {
        return orders.OrderByDescending(o => o.OrderTime).ToList();
    }

    public List<Order> GetTodayOrders()
    {
        return orders.Where(o => o.OrderTime.Date == DateTime.Today).ToList();
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public decimal GetTotalRevenueForPeriod(DateTime start, DateTime end)
    {
        return orders.Where(o => o.CloseTime >= start && o.CloseTime <= end && o.IsPaid)
                    .Sum(o => o.TotalPrice);
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public Dictionary<string, decimal> GetWaiterStatistics(DateTime start, DateTime end)
    {
        return orders.Where(o => o.CloseTime >= start && o.CloseTime <= end && o.IsPaid)
                    .GroupBy(o => o.WaiterName)
                    .ToDictionary(g => g.Key, g => g.Sum(o => o.TotalPrice));
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public Dictionary<string, int> GetDishStatistics(DateTime start, DateTime end)
    {
        var stats = new Dictionary<string, int>();
        var periodOrders = orders.Where(o => o.OrderTime >= start && o.OrderTime <= end);

        foreach (var order in periodOrders)
        {
            foreach (var dish in order.Dishes)
            {
                if (stats.ContainsKey(dish.Name))
                    stats[dish.Name]++;
                else
                    stats[dish.Name] = 1;
            }
        }
        return stats.OrderByDescending(s => s.Value).ToDictionary(s => s.Key, s => s.Value);
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public void UpdateOrderStatus(int orderId, OrderStatus newStatus, out bool success)
    {
        var order = orders.FirstOrDefault(o => o.Id == orderId);
        if (order != null)
        {
            order.UpdateStatus(newStatus, out success);
        }
        else
        {
            success = false;
        }
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public void MarkOrderAsPaid(int orderId, out bool success)
    {
        var order = orders.FirstOrDefault(o => o.Id == orderId);
        if (order != null)
        {
            order.MarkAsPaid(out success);
        }
        else
        {
            success = false;
        }
    }

    public List<Waiter> GetAllWaiters()
    {
        return waiters.Where(w => w.IsActive).ToList();
    }

    public void AddWaiter(in string name, in string phone, out Waiter waiter)
    {
        waiter = new Waiter().CreateWaiter(nextWaiterId++, name, phone);
        waiters.Add(waiter);
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public void ToggleDishAvailability(int dishId, out bool newStatus)
    {
        var dish = dishes.FirstOrDefault(d => d.Id == dishId);
        if (dish != null)
        {
            dish.ToggleAvailability(out newStatus);
        }
        else
        {
            newStatus = false;
        }
    }

    // ИСПРАВЛЕНО: убраны модификаторы in
    public Order GetOrderById(int orderId)
    {
        return orders.FirstOrDefault(o => o.Id == orderId);
    }
}