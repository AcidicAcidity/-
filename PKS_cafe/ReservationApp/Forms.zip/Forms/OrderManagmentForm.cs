using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ReservationApp.Models;
public class OrderManagementForm : Form
{
    private OrderService orderService = null!;
    private ReservationService reservationService = null!;
    private IContainer components = null!;
    private DataGridView dgvActiveOrders = null!;
    private DataGridView dgvAllOrders = null!;
    private DataGridView dgvMenu = null!;
    private ListBox lstSelectedDishes = null!;
    private Button btnCreateOrder = null!;
    private Button btnUpdateStatus = null!;
    private Button btnMarkPaid = null!;
    private Button btnPrintReceipt = null!;
    private Button btnAddDish = null!;
    private Button btnRemoveDish = null!;
    private ComboBox cmbWaiters = null!;
    private ComboBox cmbStatus = null!;
    private NumericUpDown numTableId = null!;
    private TextBox txtOrderComment = null!;
    private Label lblTotalPrice = null!;
    private List<Dish> selectedDishes = new List<Dish>();

    public OrderManagementForm(OrderService orderService, ReservationService reservationService)
    {
        this.orderService = orderService;
        this.reservationService = reservationService;
        InitializeUI();
        LoadData();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeUI()
    {
        components = new Container();
        dgvActiveOrders = new DataGridView();
        dgvAllOrders = new DataGridView();
        dgvMenu = new DataGridView();
        lstSelectedDishes = new ListBox();
        btnCreateOrder = new Button();
        btnUpdateStatus = new Button();
        btnMarkPaid = new Button();
        btnPrintReceipt = new Button();
        btnAddDish = new Button();
        btnRemoveDish = new Button();
        cmbWaiters = new ComboBox();
        cmbStatus = new ComboBox();
        numTableId = new NumericUpDown();
        txtOrderComment = new TextBox();
        lblTotalPrice = new Label();

        this.Text = "Управление заказами";
        this.Size = new System.Drawing.Size(1300, 750);
        this.StartPosition = FormStartPosition.CenterScreen;

        var tabControl = new TabControl { Dock = DockStyle.Fill };

        // Вкладка создания заказа
        var tabCreate = new TabPage("Создание заказа");
        InitializeCreateOrderTab(tabCreate);
        tabControl.TabPages.Add(tabCreate);

        // Вкладка управления заказами
        var tabManage = new TabPage("Управление заказами");
        InitializeManageOrdersTab(tabManage);
        tabControl.TabPages.Add(tabManage);

        this.Controls.Add(tabControl);
    }

    private void InitializeCreateOrderTab(TabPage tab)
    {
        var panel = new Panel { Dock = DockStyle.Fill, AutoScroll = true };

        // Информация о заказе
        var lblTableId = new Label { Text = "Номер стола:", Location = new System.Drawing.Point(20, 20) };
        numTableId = new NumericUpDown { Location = new System.Drawing.Point(120, 20), Width = 80, Minimum = 1, Maximum = 20 };

        var lblWaiter = new Label { Text = "Официант:", Location = new System.Drawing.Point(220, 20) };
        cmbWaiters = new ComboBox { Location = new System.Drawing.Point(290, 20), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };

        var lblComment = new Label { Text = "Комментарий:", Location = new System.Drawing.Point(20, 60) };
        txtOrderComment = new TextBox { Location = new System.Drawing.Point(120, 60), Width = 300, Height = 60, Multiline = true };

        // Меню
        var lblMenu = new Label { Text = "Меню:", Location = new System.Drawing.Point(20, 140) };
        dgvMenu = new DataGridView
        {
            Location = new System.Drawing.Point(20, 170),
            Size = new System.Drawing.Size(500, 200),
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect
        };

        // Выбранные блюда
        var lblSelected = new Label { Text = "Выбранные блюда:", Location = new System.Drawing.Point(550, 140) };
        lstSelectedDishes = new ListBox
        {
            Location = new System.Drawing.Point(550, 170),
            Size = new System.Drawing.Size(300, 200)
        };

        // Кнопки
        btnAddDish = new Button { Text = "Добавить блюдо", Location = new System.Drawing.Point(20, 380), Width = 120 };
        btnAddDish.Click += (s, e) => AddDishToOrder();

        btnRemoveDish = new Button { Text = "Удалить блюдо", Location = new System.Drawing.Point(150, 380), Width = 120 };
        btnRemoveDish.Click += (s, e) => RemoveSelectedDish();

        lblTotalPrice = new Label { Text = "Итого: 0 руб.", Location = new System.Drawing.Point(550, 380), Width = 200, Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold) };

        btnCreateOrder = new Button { Text = "Создать заказ", Location = new System.Drawing.Point(20, 420), Width = 120, BackColor = System.Drawing.Color.LightGreen };
        btnCreateOrder.Click += (s, e) => CreateOrder();

        panel.Controls.AddRange(new Control[] {
            lblTableId, numTableId, lblWaiter, cmbWaiters,
            lblComment, txtOrderComment, lblMenu, dgvMenu,
            lblSelected, lstSelectedDishes, btnAddDish, btnRemoveDish,
            lblTotalPrice, btnCreateOrder
        });

        tab.Controls.Add(panel);
    }

    private void InitializeManageOrdersTab(TabPage tab)
    {
        var splitContainer = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical };

        // Верхняя панель - активные заказы
        var topPanel = new Panel { Dock = DockStyle.Fill };
        var lblActiveOrders = new Label { Text = "Активные заказы:", Location = new System.Drawing.Point(10, 10), Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold) };
        dgvActiveOrders = new DataGridView
        {
            Location = new System.Drawing.Point(10, 40),
            Size = new System.Drawing.Size(800, 200),
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect
        };

        // Нижняя панель - все заказы
        var bottomPanel = new Panel { Dock = DockStyle.Fill };
        var lblAllOrders = new Label { Text = "Все заказы:", Location = new System.Drawing.Point(10, 10), Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold) };
        dgvAllOrders = new DataGridView
        {
            Location = new System.Drawing.Point(10, 40),
            Size = new System.Drawing.Size(800, 200),
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect
        };

        // Панель управления
        var controlPanel = new Panel { Dock = DockStyle.Bottom, Height = 60 };
        var lblStatus = new Label { Text = "Статус:", Location = new System.Drawing.Point(10, 20) };
        cmbStatus = new ComboBox { Location = new System.Drawing.Point(70, 20), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
        cmbStatus.DataSource = Enum.GetValues(typeof(OrderStatus));

        btnUpdateStatus = new Button { Text = "Обновить статус", Location = new System.Drawing.Point(240, 20), Width = 120 };
        btnUpdateStatus.Click += (s, e) => UpdateOrderStatus();

        btnMarkPaid = new Button { Text = "Отметить оплату", Location = new System.Drawing.Point(370, 20), Width = 120 };
        btnMarkPaid.Click += (s, e) => MarkOrderAsPaid();

        btnPrintReceipt = new Button { Text = "Печать чека", Location = new System.Drawing.Point(500, 20), Width = 100 };
        btnPrintReceipt.Click += (s, e) => PrintReceipt();

        controlPanel.Controls.AddRange(new Control[] { lblStatus, cmbStatus, btnUpdateStatus, btnMarkPaid, btnPrintReceipt });

        topPanel.Controls.Add(lblActiveOrders);
        topPanel.Controls.Add(dgvActiveOrders);
        bottomPanel.Controls.Add(lblAllOrders);
        bottomPanel.Controls.Add(dgvAllOrders);
        bottomPanel.Controls.Add(controlPanel);

        splitContainer.Panel1.Controls.Add(topPanel);
        splitContainer.Panel2.Controls.Add(bottomPanel);

        tab.Controls.Add(splitContainer);
    }

    private void LoadData()
    {
        LoadWaiters();
        LoadMenu();
        LoadOrders();
        ConfigureDataGridViews();
    }

    private void LoadWaiters()
    {
        var waiters = orderService.GetAllWaiters();
        cmbWaiters.DataSource = waiters;
        cmbWaiters.DisplayMember = "Name";
        cmbWaiters.ValueMember = "Id";
    }

    private void LoadMenu()
    {
        var dishes = orderService.GetAllDishes().Where(d => d.IsAvailable).ToList();
        dgvMenu.DataSource = dishes.Select(d => new
        {
            d.Id,
            d.Name,
            Category = d.Category.ToString(),
            d.Price,
            CookingTime = $"{d.CookingTime} мин."
        }).ToList();
    }

    private void LoadOrders()
    {
        var activeOrders = orderService.GetActiveOrders();
        dgvActiveOrders.DataSource = activeOrders.Select(o => new
        {
            o.Id,
            o.TableId,
            o.WaiterName,
            OrderTime = o.OrderTime.ToString("dd.MM.yyyy HH:mm"),
            o.TotalPrice,
            Status = o.Status.ToString(),
            DishesCount = o.Dishes.Count
        }).ToList();

        var allOrders = orderService.GetAllOrders();
        dgvAllOrders.DataSource = allOrders.Select(o => new
        {
            o.Id,
            o.TableId,
            o.WaiterName,
            OrderTime = o.OrderTime.ToString("dd.MM.yyyy HH:mm"),
            CloseTime = o.CloseTime?.ToString("dd.MM.yyyy HH:mm") ?? "-",
            o.TotalPrice,
            Status = o.Status.ToString(),
            Paid = o.IsPaid ? "Да" : "Нет"
        }).ToList();
    }

    private void ConfigureDataGridViews()
    {
        // Настройка столбцов для активных заказов
        if (dgvActiveOrders.Columns.Count > 0)
        {
            dgvActiveOrders.Columns["Id"].Width = 50;
            dgvActiveOrders.Columns["TableId"].Width = 60;
            dgvActiveOrders.Columns["WaiterName"].Width = 120;
            dgvActiveOrders.Columns["OrderTime"].Width = 120;
            dgvActiveOrders.Columns["TotalPrice"].Width = 80;
            dgvActiveOrders.Columns["Status"].Width = 100;
            dgvActiveOrders.Columns["DishesCount"].Width = 70;
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void AddDishToOrder()
    {
        if (dgvMenu.SelectedRows.Count > 0 && dgvMenu.SelectedRows[0].Cells["Id"].Value != null)
        {
            var dishId = (int)dgvMenu.SelectedRows[0].Cells["Id"].Value;
            var dish = orderService.GetAllDishes().First(d => d.Id == dishId);
            
            selectedDishes.Add(dish);
            lstSelectedDishes.Items.Add($"{dish.Name} - {dish.Price} руб.");
            
            UpdateTotalPrice();
        }
    }

    private void RemoveSelectedDish()
    {
        if (lstSelectedDishes.SelectedIndex >= 0)
        {
            selectedDishes.RemoveAt(lstSelectedDishes.SelectedIndex);
            lstSelectedDishes.Items.RemoveAt(lstSelectedDishes.SelectedIndex);
            UpdateTotalPrice();
        }
    }

    private void UpdateTotalPrice()
    {
        var total = selectedDishes.Sum(d => d.Price);
        lblTotalPrice.Text = $"Итого: {total} руб.";
    }

    private void CreateOrder()
    {
        if (selectedDishes.Count == 0)
        {
            MessageBox.Show("Добавьте хотя бы одно блюдо в заказ", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (cmbWaiters.SelectedItem == null)
        {
            MessageBox.Show("Выберите официанта", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            var waiter = (Waiter)cmbWaiters.SelectedItem;
            orderService.CreateOrder(
                (int)numTableId.Value,
                waiter.Id,
                waiter.Name,
                txtOrderComment.Text,
                selectedDishes.ToArray()
            );

            MessageBox.Show("Заказ успешно создан!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearOrderForm();
            LoadOrders();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка создания заказа: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ClearOrderForm()
    {
        selectedDishes.Clear();
        lstSelectedDishes.Items.Clear();
        txtOrderComment.Clear();
        lblTotalPrice.Text = "Итого: 0 руб.";
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void UpdateOrderStatus()
    {
        if (dgvActiveOrders.SelectedRows.Count > 0 && dgvActiveOrders.SelectedRows[0].Cells["Id"].Value != null)
        {
            var orderId = (int)dgvActiveOrders.SelectedRows[0].Cells["Id"].Value;
            var newStatus = (OrderStatus)cmbStatus.SelectedItem;
            
            orderService.UpdateOrderStatus(orderId, newStatus, out bool success);
            
            if (success)
            {
                MessageBox.Show("Статус заказа обновлен", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadOrders();
            }
            else
            {
                MessageBox.Show("Не удалось обновить статус", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void MarkOrderAsPaid()
    {
        if (dgvAllOrders.SelectedRows.Count > 0 && dgvAllOrders.SelectedRows[0].Cells["Id"].Value != null)
        {
            var orderId = (int)dgvAllOrders.SelectedRows[0].Cells["Id"].Value;
            
            orderService.MarkOrderAsPaid(orderId, out bool success);
            
            if (success)
            {
                MessageBox.Show("Заказ отмечен как оплаченный", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadOrders();
            }
            else
            {
                MessageBox.Show("Не удалось отметить заказ как оплаченный", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // БЕЗОПАСНАЯ РАСПАКОВКА - добавлена проверка на null
    private void PrintReceipt()
    {
        if (dgvAllOrders.SelectedRows.Count > 0 && dgvAllOrders.SelectedRows[0].Cells["Id"].Value != null)
        {
            var orderId = (int)dgvAllOrders.SelectedRows[0].Cells["Id"].Value;
            var order = orderService.GetOrderById(orderId);
            
            if (order != null && order.Status == OrderStatus.Closed)
            {
                order.PrintReceipt(out string receipt);
                
                var receiptForm = new Form
                {
                    Text = $"Чек для заказа #{orderId}",
                    Size = new System.Drawing.Size(400, 500),
                    StartPosition = FormStartPosition.CenterParent
                };
                
                var textBox = new TextBox
                {
                    Text = receipt,
                    Multiline = true,
                    ReadOnly = true,
                    Dock = DockStyle.Fill,
                    Font = new System.Drawing.Font("Consolas", 10),
                    ScrollBars = ScrollBars.Vertical
                };
                
                receiptForm.Controls.Add(textBox);
                receiptForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Чек можно распечатать только для закрытых заказов", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}