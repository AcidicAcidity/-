using System;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.Collections.Generic;

namespace ReservationApp.Forms
{
    public class MainForm : Form
    {
        private ReservationService reservationService;
        private OrderService orderService;
        private TableManagementService tableManagementService;
        
        private TabControl mainTabControl;
        private MenuStrip mainMenu;
        private StatusStrip statusStrip;
        private IContainer components;

        // Контролы для Dashboard
        private Label lblTodayStats;
        private Label lblReservationsCount;
        private Label lblActiveOrdersCount;
        private Label lblRevenueToday;
        private ListBox listActiveReservations;
        private ListBox listActiveOrders;

        // Контролы для управления
        private DataGridView dgvTables;
        private DataGridView dgvReservations;
        private DataGridView dgvOrders;
        private DataGridView dgvMenu;

        public MainForm()
        {
            reservationService = new ReservationService();
            orderService = new OrderService(reservationService);
            tableManagementService = new TableManagementService(reservationService);
            
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.mainTabControl = new TabControl();
            this.mainMenu = new MenuStrip();
            this.statusStrip = new StatusStrip();
            
            this.SuspendLayout();

            // Main Form
            this.Text = "ПКС Кафе - Панель администратора";
            this.Size = new Size(1400, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            // Main Menu
            InitializeMainMenu();

            // Tab Control
            this.mainTabControl.Dock = DockStyle.Fill;
            this.mainTabControl.Location = new Point(0, 24);
            this.mainTabControl.Size = new Size(1400, 750);
            
            // Status Strip
            this.statusStrip.Location = new Point(0, 774);
            this.statusStrip.Size = new Size(1400, 26);
            this.statusStrip.Items.Add(new ToolStripStatusLabel { Text = "Готово" });

            // Create Tabs
            CreateTabs();

            // Add Controls
            this.Controls.AddRange(new Control[] {
                this.mainTabControl,
                this.statusStrip,
                this.mainMenu
            });

            this.MainMenuStrip = this.mainMenu;
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void InitializeMainMenu()
        {
            this.mainMenu = new MenuStrip();

            // File Menu
            var fileMenu = new ToolStripMenuItem("Файл");
            fileMenu.DropDownItems.Add("Экспорт отчетов", null, (s, e) => ExportReports());
            fileMenu.DropDownItems.Add(new ToolStripSeparator());
            fileMenu.DropDownItems.Add("Выход", null, (s, e) => Application.Exit());

            // View Menu
            var viewMenu = new ToolStripMenuItem("Вид");
            viewMenu.DropDownItems.Add("Обновить данные", null, (s, e) => RefreshAllData());

            // Reports Menu
            var reportsMenu = new ToolStripMenuItem("Отчеты");
            reportsMenu.DropDownItems.Add("Финансовый отчет", null, (s, e) => ShowFinancialReport());
            reportsMenu.DropDownItems.Add("Статистика официантов", null, (s, e) => ShowWaiterStatistics());
            reportsMenu.DropDownItems.Add("Статистика блюд", null, (s, e) => ShowDishStatistics());

            this.mainMenu.Items.AddRange(new ToolStripItem[] { fileMenu, viewMenu, reportsMenu });
        }

        private void CreateTabs()
        {
            // Tab 1: Dashboard
            var tabDashboard = new TabPage("📊 Обзор");
            InitializeDashboardTab(tabDashboard);
            mainTabControl.TabPages.Add(tabDashboard);

            // Tab 2: Tables
            var tabTables = new TabPage("🪑 Управление столами");
            InitializeTablesTab(tabTables);
            mainTabControl.TabPages.Add(tabTables);

            // Tab 3: Reservations
            var tabReservations = new TabPage("📅 Бронирования");
            InitializeReservationsTab(tabReservations);
            mainTabControl.TabPages.Add(tabReservations);

            // Tab 4: Orders
            var tabOrders = new TabPage("🍽️ Заказы");
            InitializeOrdersTab(tabOrders);
            mainTabControl.TabPages.Add(tabOrders);

            // Tab 5: Menu
            var tabMenu = new TabPage("📋 Управление меню");
            InitializeMenuTab(tabMenu);
            mainTabControl.TabPages.Add(tabMenu);
        }

        private void InitializeDashboardTab(TabPage tab)
        {
            var panel = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
            
            // Today Statistics
            lblTodayStats = new Label 
            { 
                Text = "СТАТИСТИКА НА СЕГОДНЯ", 
                Location = new Point(20, 20),
                Font = new Font("Arial", 14, FontStyle.Bold),
                AutoSize = true
            };

            lblReservationsCount = new Label
            {
                Text = "Бронирования: загрузка...",
                Location = new Point(40, 60),
                AutoSize = true
            };

            lblActiveOrdersCount = new Label
            {
                Text = "Активные заказы: загрузка...",
                Location = new Point(40, 90),
                AutoSize = true
            };

            lblRevenueToday = new Label
            {
                Text = "Выручка за сегодня: загрузка...",
                Location = new Point(40, 120),
                AutoSize = true
            };

            // Active Reservations
            var lblActiveReservations = new Label
            {
                Text = "АКТИВНЫЕ БРОНИРОВАНИЯ:",
                Location = new Point(20, 160),
                Font = new Font("Arial", 10, FontStyle.Bold),
                AutoSize = true
            };

            listActiveReservations = new ListBox
            {
                Location = new Point(40, 190),
                Size = new Size(400, 150)
            };

            // Active Orders
            var lblActiveOrdersList = new Label
            {
                Text = "АКТИВНЫЕ ЗАКАЗЫ:",
                Location = new Point(500, 160),
                Font = new Font("Arial", 10, FontStyle.Bold),
                AutoSize = true
            };

            listActiveOrders = new ListBox
            {
                Location = new Point(520, 190),
                Size = new Size(400, 150)
            };

            panel.Controls.AddRange(new Control[] {
                lblTodayStats, lblReservationsCount, lblActiveOrdersCount, lblRevenueToday,
                lblActiveReservations, listActiveReservations,
                lblActiveOrdersList, listActiveOrders
            });

            tab.Controls.Add(panel);
        }

        private void InitializeTablesTab(TabPage tab)
        {
            var splitContainer = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical
            };

            // Left Panel - Tables List
            var leftPanel = new Panel { Dock = DockStyle.Fill };
            
            var lblTables = new Label 
            { 
                Text = "СПИСОК СТОЛОВ", 
                Location = new Point(10, 10),
                Font = new Font("Arial", 12, FontStyle.Bold),
                AutoSize = true
            };

            dgvTables = new DataGridView
            {
                Location = new Point(10, 40),
                Size = new Size(400, 500),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false
            };

            dgvTables.Columns.Add("Id", "ID");
            dgvTables.Columns.Add("Location", "Расположение");
            dgvTables.Columns.Add("Seats", "Мест");
            dgvTables.Columns.Add("Status", "Статус");

            // Right Panel - Table Details
            var rightPanel = new Panel { Dock = DockStyle.Fill };
            
            var lblTableDetails = new Label 
            { 
                Text = "ИНФОРМАЦИЯ О СТОЛЕ", 
                Location = new Point(10, 10),
                Font = new Font("Arial", 12, FontStyle.Bold),
                AutoSize = true
            };

            var txtTableInfo = new TextBox
            {
                Location = new Point(10, 40),
                Size = new Size(400, 200),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical
            };

            var btnToggleTable = new Button 
            { 
                Text = "Активировать/Деактивировать", 
                Location = new Point(10, 250),
                Size = new Size(200, 30)
            };

            btnToggleTable.Click += (s, e) =>
            {
                if (dgvTables.SelectedRows.Count > 0 && dgvTables.SelectedRows[0].Cells["Id"].Value != null)
                {
                    var tableId = (int)dgvTables.SelectedRows[0].Cells["Id"].Value;
                    tableManagementService.ToggleTableStatus(tableId, out bool newStatus);
                    RefreshTablesData();
                    UpdateStatusStrip();
                }
            };

            dgvTables.SelectionChanged += (s, e) =>
            {
                if (dgvTables.SelectedRows.Count > 0 && dgvTables.SelectedRows[0].Cells["Id"].Value != null)
                {
                    var tableId = (int)dgvTables.SelectedRows[0].Cells["Id"].Value;
                    var info = tableManagementService.GetTableDetailedInfo(tableId);
                    txtTableInfo.Text = info;
                }
            };

            leftPanel.Controls.AddRange(new Control[] { lblTables, dgvTables });
            rightPanel.Controls.AddRange(new Control[] { lblTableDetails, txtTableInfo, btnToggleTable });

            splitContainer.Panel1.Controls.Add(leftPanel);
            splitContainer.Panel2.Controls.Add(rightPanel);

            tab.Controls.Add(splitContainer);
        }

        private void InitializeReservationsTab(TabPage tab)
        {
            dgvReservations = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoGenerateColumns = false
            };

            dgvReservations.Columns.Add("Id", "ID");
            dgvReservations.Columns.Add("ClientName", "Клиент");
            dgvReservations.Columns.Add("Phone", "Телефон");
            dgvReservations.Columns.Add("StartTime", "Начало");
            dgvReservations.Columns.Add("EndTime", "Окончание");
            dgvReservations.Columns.Add("Table", "Стол");
            dgvReservations.Columns.Add("Status", "Статус");

            tab.Controls.Add(dgvReservations);
        }

        private void InitializeOrdersTab(TabPage tab)
        {
            dgvOrders = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoGenerateColumns = false
            };

            dgvOrders.Columns.Add("Id", "ID");
            dgvOrders.Columns.Add("TableId", "Стол");
            dgvOrders.Columns.Add("WaiterName", "Официант");
            dgvOrders.Columns.Add("OrderTime", "Время заказа");
            dgvOrders.Columns.Add("TotalPrice", "Стоимость");
            dgvOrders.Columns.Add("Status", "Статус");
            dgvOrders.Columns.Add("DishesCount", "Кол-во блюд");

            tab.Controls.Add(dgvOrders);
        }

        private void InitializeMenuTab(TabPage tab)
        {
            dgvMenu = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoGenerateColumns = false
            };

            dgvMenu.Columns.Add("Id", "ID");
            dgvMenu.Columns.Add("Name", "Название");
            dgvMenu.Columns.Add("Category", "Категория");
            dgvMenu.Columns.Add("Price", "Цена");
            dgvMenu.Columns.Add("CookingTime", "Время готовки");
            dgvMenu.Columns.Add("Available", "Доступно");

            tab.Controls.Add(dgvMenu);
        }

        private void LoadData()
        {
            RefreshDashboard();
            RefreshTablesData();
            RefreshReservationsData();
            RefreshOrdersData();
            RefreshMenuData();
            UpdateStatusStrip();
        }

        private void RefreshDashboard()
        {
            try
            {
                var todayReservations = reservationService.GetTodayReservations();
                var activeOrders = orderService.GetActiveOrders();
                var todayRevenue = orderService.GetTotalRevenueForPeriod(DateTime.Today, DateTime.Today.AddDays(1));

                lblReservationsCount.Text = $"Бронирования: {todayReservations.Count}";
                lblActiveOrdersCount.Text = $"Активные заказы: {activeOrders.Count}";
                lblRevenueToday.Text = $"Выручка за сегодня: {todayRevenue} руб.";

                // Active Reservations
                listActiveReservations.Items.Clear();
                foreach (var res in todayReservations.Where(r => r.IsActive()))
                {
                    listActiveReservations.Items.Add($"{res.StartTime:HH:mm} - Стол #{res.AssignedTable?.Id} - {res.ClientName}");
                }

                // Active Orders
                listActiveOrders.Items.Clear();
                foreach (var order in activeOrders)
                {
                    listActiveOrders.Items.Add($"Заказ #{order.Id} - Стол {order.TableId} - {order.TotalPrice} руб.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления дашборда: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshTablesData()
        {
            try
            {
                var tables = reservationService.GetAllTables();
                dgvTables.Rows.Clear();

                foreach (var table in tables)
                {
                    dgvTables.Rows.Add(
                        table.Id,
                        table.Location.ToString(),
                        table.Seats,
                        table.IsActive ? "Активен" : "Неактивен"
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки столов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshReservationsData()
        {
            try
            {
                var reservations = reservationService.GetAllReservations();
                dgvReservations.Rows.Clear();

                foreach (var res in reservations)
                {
                    var status = res.IsActive() ? "Активна" : 
                                res.StartTime > DateTime.Now ? "Ожидание" : "Завершена";
                    
                    dgvReservations.Rows.Add(
                        res.Id,
                        res.ClientName,
                        res.Phone,
                        res.StartTime.ToString("dd.MM.yyyy HH:mm"),
                        res.EndTime.ToString("dd.MM.yyyy HH:mm"),
                        res.AssignedTable?.Id,
                        status
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки бронирований: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshOrdersData()
        {
            try
            {
                var orders = orderService.GetActiveOrders();
                dgvOrders.Rows.Clear();

                foreach (var order in orders)
                {
                    dgvOrders.Rows.Add(
                        order.Id,
                        order.TableId,
                        order.WaiterName,
                        order.OrderTime.ToString("dd.MM.yyyy HH:mm"),
                        order.TotalPrice,
                        order.Status.ToString(),
                        order.Dishes.Count
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshMenuData()
        {
            try
            {
                var dishes = orderService.GetAllDishes();
                dgvMenu.Rows.Clear();

                foreach (var dish in dishes)
                {
                    dgvMenu.Rows.Add(
                        dish.Id,
                        dish.Name,
                        dish.Category.ToString(),
                        $"{dish.Price} руб.",
                        $"{dish.CookingTime} мин.",
                        dish.IsAvailable ? "Да" : "Нет"
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки меню: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshAllData()
        {
            LoadData();
            UpdateStatusStrip();
        }

        private void UpdateStatusStrip()
        {
            try
            {
                var activeOrders = orderService.GetActiveOrders().Count;
                var todayReservations = reservationService.GetTodayReservations().Count;
                
                if (statusStrip.Items.Count > 0)
                {
                    statusStrip.Items[0].Text = $"Активных заказов: {activeOrders} | Бронирований сегодня: {todayReservations} | Обновлено: {DateTime.Now:HH:mm:ss}";
                }
            }
            catch (Exception ex)
            {
                if (statusStrip.Items.Count > 0)
                {
                    statusStrip.Items[0].Text = $"Ошибка: {ex.Message}";
                }
            }
        }

        private void ExportReports()
        {
            MessageBox.Show("Функция экспорта отчетов будет реализована в следующей версии", "Информация", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowFinancialReport()
        {
            try
            {
                var monthRevenue = orderService.GetTotalRevenueForPeriod(
                    new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1), 
                    DateTime.Today);
                    
                MessageBox.Show($"Финансовый отчет за текущий месяц:\nВыручка: {monthRevenue} руб.", "Финансовый отчет");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка формирования отчета: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowWaiterStatistics()
        {
            try
            {
                var stats = orderService.GetWaiterStatistics(
                    new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1), 
                    DateTime.Today);
                    
                var message = "Статистика официантов за текущий месяц:\n";
                foreach (var stat in stats.OrderByDescending(s => s.Value))
                {
                    message += $"{stat.Key}: {stat.Value} руб.\n";
                }
                
                MessageBox.Show(message, "Статистика официантов");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка формирования статистики: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowDishStatistics()
        {
            try
            {
                var stats = orderService.GetDishStatistics(
                    new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1), 
                    DateTime.Today);
                    
                var message = "Статистика блюд за текущий месяц:\n";
                int count = 0;
                foreach (var stat in stats.Take(10))
                {
                    message += $"{stat.Key}: {stat.Value} заказов\n";
                    count++;
                }
                
                MessageBox.Show(message, "Статистика блюд");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка формирования статистики: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}