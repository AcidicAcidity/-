using System.Linq;

public enum TableLocation
{
    Window,
    Aisle,
    Exit,
    Back
}

public enum DishCategory
{
    Drinks,
    Salads,
    ColdAppetizers,
    HotAppetizers,
    Soups,
    MainCourses,
    Desserts
}

public enum OrderStatus
{
    Active,
    Cooking,
    Ready,
    Served,
    Closed
}